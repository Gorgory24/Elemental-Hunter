//
//  FicheView.swift
//  ElementalHunterv3
//
//  Created by etudiant on 04/11/2019.
//  Copyright © 2019 Hydrogene&Gorgory. All rights reserved.
//

import UIKit
import CoreMotion
class FicheView: UIViewController, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
    
    @IBOutlet weak var ImagePicker: UIImageView!
    var PC = UIImagePickerController()
    struct AppUtility {

        static func lockOrientation(_ orientation: UIInterfaceOrientationMask) {

            if let delegate = UIApplication.shared.delegate as? AppDelegate {
                delegate.orientationLock = orientation
            }
        }

        /// OPTIONAL Added method to adjust lock and rotate to the desired orientation
        static func lockOrientation(_ orientation: UIInterfaceOrientationMask, andRotateTo rotateOrientation:UIInterfaceOrientation) {

            self.lockOrientation(orientation)

            UIDevice.current.setValue(rotateOrientation.rawValue, forKey: "orientation")
            UINavigationController.attemptRotationToDeviceOrientation()
        }

    }
    
    let manager = CMMotionManager()
    
    @IBOutlet weak var DTLabel: UILabel!
    @IBOutlet weak var LPLabel: UITextField!
    @IBOutlet weak var ATKMLabel: UILabel!
    @IBOutlet weak var ATKPLabel: UILabel!
    @IBOutlet weak var PhotoButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        DTLabel.text = NSLocalizedString("dt", comment: "Labels")
        LPLabel.text = NSLocalizedString("life", comment: "Labels")
        ATKMLabel.text = NSLocalizedString("ATKM", comment: "Labels")
        ATKPLabel.text = NSLocalizedString("ATKP", comment: "Labels")
        let date = Date()
        let calendar = Calendar.current
        let hour = calendar.component(.hour,from:date)
        var theme = ""
        if (hour >= 6 && hour < 10)
        {
            theme="MATIN"
        }
        else if (hour >= 10 && hour < 18)
        {
            theme="MIDI"
        }
        else
        {
            theme="SOIR"
        }
        
        switch (theme) {
        case "MATIN":
            UIGraphicsBeginImageContext(self.view.frame.size)
            UIImage(named: "matin.png")?.draw(in: self.view.bounds)
            let image: UIImage = UIGraphicsGetImageFromCurrentImageContext()!
            UIGraphicsEndImageContext()
            self.view.backgroundColor = UIColor(patternImage: image)
            break
        case "MIDI":
            UIGraphicsBeginImageContext(self.view.frame.size)
            UIImage(named: "midi.png")?.draw(in: self.view.bounds)
            let image: UIImage = UIGraphicsGetImageFromCurrentImageContext()!
            UIGraphicsEndImageContext()
            self.view.backgroundColor = UIColor(patternImage: image)
            break
        case "SOIR":
            UIGraphicsBeginImageContext(self.view.frame.size)
            UIImage(named: "soir.png")?.draw(in: self.view.bounds)
            let image: UIImage = UIGraphicsGetImageFromCurrentImageContext()!
            UIGraphicsEndImageContext()
            self.view.backgroundColor = UIColor(patternImage: image)
            break
        default:
            self.view.backgroundColor = UIColor.white
            break
        }
    }

    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        PC.dismiss(animated: true, completion: nil)
        ImagePicker.image = info[.originalImage] as? UIImage
    }
    
    override func becomeFirstResponder() -> Bool {
        return true
    }
    
    override func motionEnded(_ motion: UIEvent.EventSubtype, with event: UIEvent?) {
        if motion == .motionShake
        {
            let number : Int = Int(arc4random_uniform(30)+1)
            let NSnumber = number as NSNumber
            let Stringnumber : String = NSnumber.stringValue
            ATK.text = Stringnumber
        }
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func BackTap(_ sender: UITapGestureRecognizer) {
        manager.stopAccelerometerUpdates()
        if sender.state == .ended {
            dismiss(animated: true, completion: nil)
        }
    }
    
    @IBAction func TakePic(_ sender: Any) {
        PC.delegate = self
        PC.sourceType = .camera
        
        present(PC, animated: true, completion: nil)
        
        PhotoButton.setTitle("", for: .normal)
    }
    
    @IBOutlet weak var ATK: UITextField!
    
    @IBAction func ATKM(_ sender: UISwipeGestureRecognizer) {
        let number : Int = Int(arc4random_uniform(30)+1)
        let NSnumber = number as NSNumber
        let Stringnumber : String = NSnumber.stringValue
        ATK.text = Stringnumber
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)

        AppUtility.lockOrientation(.portrait)
        // Or to rotate and lock
        // AppUtility.lockOrientation(.portrait, andRotateTo: .portrait)

    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)

        // Don't forget to reset when view is being removed
        AppUtility.lockOrientation(.all)
    }
    
}
