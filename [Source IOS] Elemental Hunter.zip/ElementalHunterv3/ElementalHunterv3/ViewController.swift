//
//  ViewController.swift
//  ElementalHunterv3
//
//  Created by etudiant on 04/11/2019.
//  Copyright © 2019 Hydrogene&Gorgory. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController, AVAudioPlayerDelegate{

    var player: AVAudioPlayer!
    
    struct AppUtility {

        static func lockOrientation(_ orientation: UIInterfaceOrientationMask) {

            if let delegate = UIApplication.shared.delegate as? AppDelegate {
                delegate.orientationLock = orientation
            }
        }

        /// OPTIONAL Added method to adjust lock and rotate to the desired orientation
        static func lockOrientation(_ orientation: UIInterfaceOrientationMask, andRotateTo rotateOrientation:UIInterfaceOrientation) {

            self.lockOrientation(orientation)

            UIDevice.current.setValue(rotateOrientation.rawValue, forKey: "orientation")
            UINavigationController.attemptRotationToDeviceOrientation()
        }

    }
    @IBOutlet weak var StartButton: UIButton!
    @IBOutlet weak var WhereButton: UIButton!
    @IBOutlet weak var QuitButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        StartButton.setTitle(NSLocalizedString("start", comment: "Labels"), for: .normal)
        WhereButton.setTitle(NSLocalizedString("meet", comment: "Labels"), for: .normal)
        QuitButton.setTitle(NSLocalizedString("quit", comment: "Labels"), for: .normal)
        let date = Date()
        let calendar = Calendar.current
        let hour = calendar.component(.hour,from:date)
        var theme = ""
        if (hour >= 6 && hour < 10)
        {
            theme="MATIN"
        }
        else if (hour >= 10 && hour < 18)
        {
            theme="MIDI"
        }
        else
        {
            theme="SOIR"
        }
        
        switch (theme) {
        case "MATIN":
            UIGraphicsBeginImageContext(self.view.frame.size)
            UIImage(named: "matin.png")?.draw(in: self.view.bounds)
            let image: UIImage = UIGraphicsGetImageFromCurrentImageContext()!
            UIGraphicsEndImageContext()
            self.view.backgroundColor = UIColor(patternImage: image)
            break
        case "MIDI":
            UIGraphicsBeginImageContext(self.view.frame.size)
            UIImage(named: "midi.png")?.draw(in: self.view.bounds)
            let image: UIImage = UIGraphicsGetImageFromCurrentImageContext()!
            UIGraphicsEndImageContext()
            self.view.backgroundColor = UIColor(patternImage: image)
            break
        case "SOIR":
            UIGraphicsBeginImageContext(self.view.frame.size)
            UIImage(named: "soir.png")?.draw(in: self.view.bounds)
            let image: UIImage = UIGraphicsGetImageFromCurrentImageContext()!
            UIGraphicsEndImageContext()
            self.view.backgroundColor = UIColor(patternImage: image)
            break
        default:
            self.view.backgroundColor = UIColor.white
            break
        }
    }
    @IBAction func StartSong(_ sender: Any) {
        if let soundFilePath = Bundle.main.path(forResource:"sum", ofType:"mp3")
        {
            let fileURL = URL(fileURLWithPath: soundFilePath)
            do
            {
                if(player == nil)
                {
                    try player = AVAudioPlayer(contentsOf: fileURL)
                    player.delegate = self
                    if(!player.isPlaying)
                    {
                        player.stop()
                        player.play()
                        player.numberOfLoops = -1
                    }
                }
            }
            catch
            {
                print("erreur")
            }
        }
    }
    
    @IBAction func Quit(_ sender: Any) {
        exit(0)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

     override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)

        AppUtility.lockOrientation(.portrait)
        // Or to rotate and lock
        // AppUtility.lockOrientation(.portrait, andRotateTo: .portrait)

    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)

        // Don't forget to reset when view is being removed
        AppUtility.lockOrientation(.all)
    }
    
}

