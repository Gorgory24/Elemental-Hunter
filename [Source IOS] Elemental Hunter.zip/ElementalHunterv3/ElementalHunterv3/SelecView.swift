//
//  SelecView.swift
//  ElementalHunterv3
//
//  Created by etudiant on 04/11/2019.
//  Copyright © 2019 Hydrogene&Gorgory. All rights reserved.
//


import UIKit

class SelecView: UIViewController {
    
    struct AppUtility {

        static func lockOrientation(_ orientation: UIInterfaceOrientationMask) {

            if let delegate = UIApplication.shared.delegate as? AppDelegate {
                delegate.orientationLock = orientation
            }
        }

        /// OPTIONAL Added method to adjust lock and rotate to the desired orientation
        static func lockOrientation(_ orientation: UIInterfaceOrientationMask, andRotateTo rotateOrientation:UIInterfaceOrientation) {

            self.lockOrientation(orientation)

            UIDevice.current.setValue(rotateOrientation.rawValue, forKey: "orientation")
            UINavigationController.attemptRotationToDeviceOrientation()
        }

    }
    
    @IBOutlet weak var LaunchButton: UIButton!
    @IBOutlet weak var BackButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        LaunchButton.setTitle(NSLocalizedString("launch", comment: "Labels"), for: .normal)
        BackButton.setTitle(NSLocalizedString("back", comment: "Labels"), for: .normal)
        let date = Date()
        let calendar = Calendar.current
        let hour = calendar.component(.hour,from:date)
        var theme = ""
        if (hour >= 6 && hour < 10)
        {
            theme="MATIN"
        }
        else if (hour >= 10 && hour < 18)
        {
            theme="MIDI"
        }
        else
        {
            theme="SOIR"
        }
        
        switch (theme) {
        case "MATIN":
            UIGraphicsBeginImageContext(self.view.frame.size)
            UIImage(named: "matin.png")?.draw(in: self.view.bounds)
            let image: UIImage = UIGraphicsGetImageFromCurrentImageContext()!
            UIGraphicsEndImageContext()
            self.view.backgroundColor = UIColor(patternImage: image)
            break
        case "MIDI":
            UIGraphicsBeginImageContext(self.view.frame.size)
            UIImage(named: "midi.png")?.draw(in: self.view.bounds)
            let image: UIImage = UIGraphicsGetImageFromCurrentImageContext()!
            UIGraphicsEndImageContext()
            self.view.backgroundColor = UIColor(patternImage: image)
            break
        case "SOIR":
            UIGraphicsBeginImageContext(self.view.frame.size)
            UIImage(named: "soir.png")?.draw(in: self.view.bounds)
            let image: UIImage = UIGraphicsGetImageFromCurrentImageContext()!
            UIGraphicsEndImageContext()
            self.view.backgroundColor = UIColor(patternImage: image)
            break
        default:
            self.view.backgroundColor = UIColor.white
            break
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)

        AppUtility.lockOrientation(.portrait)
        // Or to rotate and lock
        // AppUtility.lockOrientation(.portrait, andRotateTo: .portrait)

    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)

        // Don't forget to reset when view is being removed
        AppUtility.lockOrientation(.all)
    }
}
